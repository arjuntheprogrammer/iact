function f1(event)
{
	var a=event.keyCode;
	alert(a);
}